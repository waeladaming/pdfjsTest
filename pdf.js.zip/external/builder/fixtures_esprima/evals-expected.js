var a = false;
var b = true;
var c = true;
var d = false;
var e = true;
var f = 'text';
var g = {
 "obj": { "i": 1 },
 "j": 2
};
var h = { 'test': 'test' };
var i = '0';
var j = { "i": 1 };
